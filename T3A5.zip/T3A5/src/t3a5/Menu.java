package t3a5;
import java.util.Scanner;

/** * * @author Raul */
public class Menu {
    public static void menu(){
        Scanner obj=new Scanner(System.in);
        Cuenta cuenta=new Cuenta();
        System.out.println(" Bienvenido a bancomer "
                + "\n1.Consultar saldo"
                + "\n2.Consultar estado de cuenta"
                + "\n3.Retirar efectivo"
                + "\n4.Otras opciones"
                + "\n5.Salir"
                + "\n\nElija una opción");
        int operacion=obj.nextInt();
        switch(operacion){
            case 1:
                cuenta.consultarSaldo();
                break;
                
            case 2:
                cuenta.estadoCuenta();
                break;
                
            case 3:
                cuenta.retirarEfectivo();
                break;
                
            case 4:
                System.out.println("Otras opciones"
                        + "\n1.Seguros"
                        + "\n2.Creditos"
                        + "\nElija uno");
                int opcion=obj.nextInt();
                switch (opcion){
                    case 1:
                        cuenta.seguros();
                        break;
                    case 2:
                        cuenta.creditos();
                        break;
                    default:
                        System.err.println("Elija una opcion valida");
                        break;
                }
                break;
            case 5:
                cuenta.salida();
                break;
            default:
                System.out.println("Elija un opcion valida");
        
        }
    }
}
    
