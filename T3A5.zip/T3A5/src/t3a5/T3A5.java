package t3a5;
import java.util.Scanner;
/** ** @author Raul*/
public class T3A5 {

    public static void main(String[] args) {
        Menu menu=new Menu();
        menu.menu();
  
    }    
}
