package t3a5;

/** * * @author Raul */
public class Cuenta {
    int pin;
    double saldo=0;
    String numeroCuenta;
    
    public Cuenta() {}

    public Cuenta(int pin, double saldo, String numeroCuenta) {
        this.pin = pin;
        this.saldo = saldo;
        this.numeroCuenta = numeroCuenta;
    }
    public void consultarSaldo(){
        System.out.println("Tienes un saldo de: " +getSaldo());
    }
    public void estadoCuenta(){
        System.out.println("ESTADO DE CUENTA\n\n"
        +"Cuenta: "+getNumeroCuenta()
        +"\nSaldo: "+getSaldo()
        +"\nUltimos movimientos");
    
    }
    public void retirarEfectivo(){
        if(getSaldo()>0){
            System.out.println("¿Cuanto desea retirar?");
        }
        else{
            System.out.println("No te puedo ayudar con esta operación"
                    +"\nFondos insuficientes");
        }
    
    }
    public void seguros(){
        System.out.println("SEGUROS"
        +"\n1.Seguro para tu auto"
        + "\n2.Seguro de vida"
        + "\n3.Seguro medico"
        + "\n4.Seguro de vivienda");
    }
    public void creditos(){
        System.out.println("CREDITOS"
                + "\n1.Hipotecario"
                + "\n2.Crediauto"
                + "\n3.Familiar"
                + "\n4.Personal"); 
    }
    public void salida(){
        System.out.println("Fin de la ejecucion ");
    }
    
    @Override
    public String toString() {
        return "Cuenta{" + "pin=" + pin + ", saldo=" + saldo + ", numeroCuenta=" + numeroCuenta + '}';
    }
    
    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    
    

    
    
    
}
